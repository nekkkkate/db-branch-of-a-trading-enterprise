create function set_modified_date() returns trigger
    language plpgsql
as
$$
BEGIN
  NEW.modified_date := now();
  RETURN NEW;
END;
$$;

alter function set_modified_date() owner to postgres;

