create procedure load_dimensions_from_branches()
    language plpgsql
as
$$
DECLARE
    branch RECORD;
BEGIN
    FOR branch IN
        SELECT database_name AS schema_name, branch_name, branch_key
        FROM dwh.dim_branch
    LOOP
        RAISE NOTICE 'Загружаем измерения из филиала: %', branch.branch_name;

        EXECUTE format('
            INSERT INTO dwh.dim_customer (
                customer_uid, customer_name, source_system
            )
            SELECT
                c.customer_uid,
                c.customer_name,
                %L
            FROM %I.customer c
            WHERE NOT EXISTS (
                SELECT 1
                FROM dwh.dim_customer dc
                WHERE dc.customer_uid = c.customer_uid
            )',
            branch.branch_name, branch.schema_name
        );

        EXECUTE format('
            INSERT INTO dwh.dim_category (
                category_uid, category_name, source_system
            )
            SELECT
                cat.category_uid,
                cat.category_name,
                %L
            FROM %I.category cat
            WHERE NOT EXISTS (
                SELECT 1
                FROM dwh.dim_category dc
                WHERE dc.category_uid = cat.category_uid
            )',
            branch.branch_name, branch.schema_name
        );

        EXECUTE format('
            INSERT INTO dwh.dim_product (
                product_uid, product_name, sku, source_system
            )
            SELECT
                p.product_uid,
                p.product_name,
                p.sku,
                %L
            FROM %I.product p
            WHERE NOT EXISTS (
                SELECT 1
                FROM dwh.dim_product dp
                WHERE dp.product_uid = p.product_uid
            )',
            branch.branch_name, branch.schema_name
        );

        EXECUTE format('
            INSERT INTO dwh.dim_product_category (
                product_key, category_key, source_uid
            )
            SELECT
                dp.product_key,
                dc.category_key,
                pc.uid_product_category
            FROM %I.product_category pc
            JOIN %I.product p ON p.id = pc.product_id
            JOIN %I.category c ON c.id = pc.category_id
            JOIN dwh.dim_product dp ON dp.product_uid = p.product_uid
            JOIN dwh.dim_category dc ON dc.category_uid = c.category_uid
            WHERE NOT EXISTS (
                SELECT 1
                FROM dwh.dim_product_category dpc
                WHERE dpc.source_uid = pc.uid_product_category
            )',
            branch.schema_name, branch.schema_name, branch.schema_name
        );

        EXECUTE format('
            INSERT INTO dwh.dim_sale (
                sale_uid, sale_number, source_system
            )
            SELECT
                s.sale_uid,
                ''SALE-'' || s.id::text,
                %L
            FROM %I.sale s
            WHERE NOT EXISTS (
                SELECT 1
                FROM dwh.dim_sale ds
                WHERE ds.sale_uid = s.sale_uid
            )',
            branch.branch_name, branch.schema_name
        );

    END LOOP;
END;
$$;

alter procedure load_dimensions_from_branches() owner to postgres;

