create procedure load_weekly_sales_from_dwh(IN p_start_date date DEFAULT NULL::date, IN p_end_date date DEFAULT NULL::date)
    language plpgsql
as
$$
DECLARE
    v_records_processed INTEGER;
    v_weeks_count INTEGER;
    v_fact_sales_count INTEGER;
    v_dim_week_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO v_fact_sales_count FROM dwh.fact_sales;
    SELECT COUNT(*) INTO v_dim_week_count FROM mart.dim_week;

    RAISE NOTICE 'Диагностика: fact_sales records: %, dim_week records: %',
        v_fact_sales_count, v_dim_week_count;

    IF p_start_date IS NULL THEN
        p_start_date := (CURRENT_DATE - INTERVAL '35 days')::date;
    END IF;

    IF p_end_date IS NULL THEN
        p_end_date := CURRENT_DATE;
    END IF;

    RAISE NOTICE 'Начало загрузки данных в витрину за период с % по %', p_start_date, p_end_date;

    IF v_dim_week_count = 0 THEN
        RAISE NOTICE 'Таблица dim_week пустая. Заполняем календарь...';
        CALL mart.populate_week_calendar(p_start_date - INTERVAL '1 year', p_end_date + INTERVAL '1 year');
    END IF;

    WITH weekly_sales AS (
        SELECT
            dw.week_key,
            fs.branch_key,
            fs.product_key,
            SUM(fs.quantity) as total_quantity,
            SUM(fs.line_total) as total_revenue,
            COUNT(DISTINCT fs.sale_key) as sales_count
        FROM dwh.fact_sales fs
        JOIN mart.dim_week dw ON fs.sale_date::date BETWEEN dw.week_start_date AND dw.week_end_date
        WHERE fs.sale_date::date BETWEEN p_start_date AND p_end_date
        GROUP BY
            dw.week_key,
            fs.branch_key,
            fs.product_key
    )
    INSERT INTO mart.fact_weekly_sales (
        week_key,
        branch_key,
        product_key,
        total_quantity,
        total_revenue,
        sales_count
    )
    SELECT
        week_key,
        branch_key,
        product_key,
        total_quantity,
        total_revenue,
        sales_count
    FROM weekly_sales
    ON CONFLICT (week_key, branch_key, product_key)
    DO UPDATE SET
        total_quantity = EXCLUDED.total_quantity,
        total_revenue = EXCLUDED.total_revenue,
        sales_count = EXCLUDED.sales_count,
        last_update = CURRENT_TIMESTAMP;

    GET DIAGNOSTICS v_records_processed = ROW_COUNT;

    RAISE NOTICE 'Загрузка завершена. Обработано записей: %', v_records_processed;

    SELECT COUNT(*) INTO v_weeks_count FROM mart.fact_weekly_sales;
    RAISE NOTICE 'Всего записей в fact_weekly_sales: %', v_weeks_count;
END;
$$;

alter procedure load_weekly_sales_from_dwh(date, date) owner to postgres;

