create procedure rebuild_mart()
    language plpgsql
as
$$
BEGIN
    RAISE NOTICE '=== ПЕРЕЗАГРУЗКА ВИТРИНЫ ДАННЫХ ===';

    -- Шаг 1: Проверка качества данных
    RAISE NOTICE '1. Проверка качества данных...';
    PERFORM * FROM mart.check_data_quality();

    -- Шаг 2: Очистка витрины
    RAISE NOTICE '2. Очистка витрины...';
    TRUNCATE TABLE mart.fact_weekly_sales;

    -- Шаг 3: Заполнение календаря недель
    RAISE NOTICE '3. Заполнение календаря недель...';
    CALL mart.populate_week_calendar();

    -- Шаг 4: Загрузка данных
    RAISE NOTICE '4. Загрузка данных в витрину...';
    CALL mart.load_weekly_sales_from_dwh();

    -- Шаг 5: Финальная статистика
    RAISE NOTICE '5. Финальная статистика...';
    PERFORM * FROM mart.get_mart_statistics();

    RAISE NOTICE '=== ПЕРЕЗАГРУЗКА ЗАВЕРШЕНА ===';
END;
$$;

alter procedure rebuild_mart() owner to postgres;

