create procedure rebuild_mart()
    language plpgsql
as
$$
DECLARE
    v_stats RECORD;
BEGIN
    RAISE NOTICE '=== ПЕРЕЗАГРУЗКА ВИТРИНЫ ДАННЫХ ===';

    RAISE NOTICE '1. Проверка качества данных...';
    PERFORM * FROM mart.check_data_quality();

    RAISE NOTICE '2. Очистка витрины...';
    TRUNCATE TABLE mart.fact_weekly_sales;

    RAISE NOTICE '3. Заполнение календаря недель...';
    CALL mart.populate_week_calendar();

    RAISE NOTICE '4. Загрузка данных в витрину...';
    CALL mart.load_weekly_sales_from_dwh();

    RAISE NOTICE '5. Финальная статистика...';

    SELECT * INTO v_stats FROM mart.get_mart_statistics();

    RAISE NOTICE 'Статистика витрины:';
    RAISE NOTICE '  - Недель в календаре: %', v_stats.total_weeks;
    RAISE NOTICE '  - Филиалов: %', v_stats.total_branches;
    RAISE NOTICE '  - Товаров: %', v_stats.total_products;
    RAISE NOTICE '  - Записей в фактах: %', v_stats.total_records;
    RAISE NOTICE '  - Последнее обновление: %', v_stats.last_update;

    RAISE NOTICE '=== ПЕРЕЗАГРУЗКА ЗАВЕРШЕНА ===';
END;
$$;

alter procedure rebuild_mart() owner to postgres;

