create procedure populate_week_calendar(IN p_start_date date DEFAULT NULL::date, IN p_end_date date DEFAULT NULL::date)
    language plpgsql
as
$$
DECLARE
    v_current_date DATE;
    v_week_start DATE;
    v_week_end DATE;
    v_year INT;
    v_iso_week INT;
    v_week_key INT;
BEGIN
    IF p_start_date IS NULL THEN
        p_start_date := CURRENT_DATE - INTERVAL '2 years';
    END IF;

    IF p_end_date IS NULL THEN
        p_end_date := CURRENT_DATE + INTERVAL '2 years';
    END IF;

    RAISE NOTICE 'Заполнение календаря недель с % по %', p_start_date, p_end_date;

    v_current_date := p_start_date;

    -- Находим начало недели (понедельник)
    v_week_start := v_current_date - EXTRACT(ISODOW FROM v_current_date)::INT + 1;

    WHILE v_week_start <= p_end_date LOOP
        v_week_end := v_week_start + 6;
        v_year := EXTRACT(YEAR FROM v_week_start);
        v_iso_week := EXTRACT(WEEK FROM v_week_start);
        v_week_key := (v_year * 100) + v_iso_week;

        INSERT INTO mart.dim_week (
            week_key,
            week_start_date,
            week_end_date,
            year,
            iso_week
        )
        VALUES (
            v_week_key,
            v_week_start,
            v_week_end,
            v_year,
            v_iso_week
        )
        ON CONFLICT (week_key) DO NOTHING;

        v_week_start := v_week_start + 7;
    END LOOP;

    RAISE NOTICE 'Календарь неделей заполнен';
END;
$$;

alter procedure populate_week_calendar(date, date) owner to postgres;

