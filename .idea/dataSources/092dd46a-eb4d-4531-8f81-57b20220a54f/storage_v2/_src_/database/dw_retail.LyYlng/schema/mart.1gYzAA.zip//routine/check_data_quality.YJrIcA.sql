create function check_data_quality()
    returns TABLE(table_name text, record_count bigint, min_date timestamp with time zone, max_date timestamp with time zone)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        'dwh.fact_sales'::TEXT,
        COUNT(*),
        MIN(sale_date),
        MAX(sale_date)
    FROM dwh.fact_sales;

    RETURN QUERY
    SELECT
        'mart.dim_week'::TEXT,
        COUNT(*),
        MIN(week_start_date)::TIMESTAMPTZ,
        MAX(week_end_date)::TIMESTAMPTZ
    FROM mart.dim_week;

    RETURN QUERY
    SELECT
        'mart.fact_weekly_sales'::TEXT,
        COUNT(*),
        MIN(dw.week_start_date)::TIMESTAMPTZ,
        MAX(dw.week_end_date)::TIMESTAMPTZ
    FROM mart.fact_weekly_sales fws
    JOIN mart.dim_week dw ON fws.week_key = dw.week_key;
END;
$$;

alter function check_data_quality() owner to postgres;

