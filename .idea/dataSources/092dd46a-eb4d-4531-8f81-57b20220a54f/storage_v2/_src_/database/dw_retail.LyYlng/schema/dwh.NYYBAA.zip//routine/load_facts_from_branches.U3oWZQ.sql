create procedure load_facts_from_branches()
    language plpgsql
as
$$
DECLARE
    branch RECORD;
BEGIN
    FOR branch IN
        SELECT database_name AS schema_name, branch_name, branch_key
        FROM dwh.dim_branch
    LOOP
        RAISE NOTICE 'Загружаем факты из филиала: %', branch.branch_name;

        EXECUTE format('
            INSERT INTO dwh.dim_date (date_key, full_date, year, quarter, month, month_name, day, weekday, weekday_name, is_weekend)
            SELECT DISTINCT
                TO_CHAR(s.sale_date, ''YYYYMMDD'')::int as date_key,
                s.sale_date::date as full_date,
                EXTRACT(YEAR FROM s.sale_date) as year,
                EXTRACT(QUARTER FROM s.sale_date) as quarter,
                EXTRACT(MONTH FROM s.sale_date) as month,
                TO_CHAR(s.sale_date, ''Month'') as month_name,
                EXTRACT(DAY FROM s.sale_date) as day,
                EXTRACT(ISODOW FROM s.sale_date) as weekday,
                TO_CHAR(s.sale_date, ''Day'') as weekday_name,
                EXTRACT(ISODOW FROM s.sale_date) IN (6,7) as is_weekend
            FROM %I.sale s
            WHERE NOT EXISTS (
                SELECT 1
                FROM dwh.dim_date dd
                WHERE dd.full_date = s.sale_date::date
            )',
            branch.schema_name
        );

        EXECUTE format('
            INSERT INTO dwh.fact_sales (
                customer_key, product_key, branch_key, sale_key,
                sale_date_key, sale_uid, sale_item_uid, quantity,
                unit_price, sale_date, source_system
            )
            SELECT
                dc.customer_key,
                dp.product_key,
                %s as branch_key,
                ds.sale_key,
                TO_CHAR(s.sale_date, ''YYYYMMDD'')::int as sale_date_key,
                s.sale_uid,
                si.sale_item_uid,
                si.quantity,
                si.unit_price,
                s.sale_date,
                %L as source_system
            FROM %I.sale_item si
            JOIN %I.sale s ON s.id = si.sale_id
            JOIN %I.customer c ON c.id = s.customer_id
            JOIN %I.product p ON p.id = si.product_id
            JOIN dwh.dim_customer dc ON dc.customer_uid = c.customer_uid
            JOIN dwh.dim_product dp ON dp.product_uid = p.product_uid
            JOIN dwh.dim_sale ds ON ds.sale_uid = s.sale_uid
            WHERE NOT EXISTS (
                SELECT 1
                FROM dwh.fact_sales fs
                WHERE fs.sale_item_uid = si.sale_item_uid
            )',
            branch.branch_key,
            branch.branch_name,
            branch.schema_name,
            branch.schema_name,
            branch.schema_name,
            branch.schema_name
        );

        RAISE NOTICE 'Завершена загрузка из филиала: %', branch.branch_name;
    END LOOP;
END;
$$;

alter procedure load_facts_from_branches() owner to postgres;

