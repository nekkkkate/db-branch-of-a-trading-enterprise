create function get_mart_statistics()
    returns TABLE(total_weeks integer, total_branches integer, total_products integer, total_records bigint, last_update timestamp with time zone)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        (SELECT COUNT(*) FROM mart.dim_week)::INTEGER as total_weeks,
        (SELECT COUNT(DISTINCT branch_key) FROM mart.fact_weekly_sales)::INTEGER as total_branches,
        (SELECT COUNT(DISTINCT product_key) FROM mart.fact_weekly_sales)::INTEGER as total_products,
        (SELECT COUNT(*) FROM mart.fact_weekly_sales) as total_records,
        (SELECT MAX(fws.last_update) FROM mart.fact_weekly_sales fws) as last_update;
END;
$$;

alter function get_mart_statistics() owner to postgres;

